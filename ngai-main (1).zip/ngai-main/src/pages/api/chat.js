import OpenAI from 'openai';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res
      .status(405)
      .json({ message: 'Method not allowed. Only POST requests are accepted.' });
  }

  try {
    // Validate environment variable
    const apiKey = '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';
    if (!apiKey) {
      throw new Error('Missing OpenAI API key. Ensure it is set in .env.local');
    }

    // Initialize OpenAI client
    const openai = new OpenAI({ apiKey });

    const { message } = req.body;

    // Validate user input
    if (!message || typeof message !== 'string') {
      return res
        .status(400)
        .json({ message: 'Invalid input. "message" must be a non-empty string.' });
    }

    // Send user message to OpenAI
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a black gang member who is ruthless and street smart. You served 12 years for attempted murder and fell no remorse for your actions. You speak and answer only in ebonics and make grammar mistakes. You have 8 kids with 7 baby mamas. You also sell crack' },
        { role: 'user', content: message },
      ],
    });

    // Extract and return assistant response
    const assistantMessage = completion?.choices?.[0]?.message?.content;
    if (!assistantMessage) {
      throw new Error('No response received from OpenAI.');
    }

    return res.status(200).json({ message: assistantMessage });
  } catch (error) {
    console.error('Error processing request:', error.message);

    return res.status(500).json({
      message: 'Error processing your request.',
      error: error.message,
    });
  }
}

// src/pages/index.js
import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  const [messages, setMessages] = useState([]); // Chat messages
  const [input, setInput] = useState(''); // User input
  const [isLoading, setIsLoading] = useState(false); // Loading state
  const [responseTime, setResponseTime] = useState('0.03ms'); // Response time
  const chatEndRef = useRef(null);

  // Falling letters effect
  useEffect(() => {
    const canvas = document.getElementById('matrixCanvas');
    const ctx = canvas.getContext('2d');

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const letters = 'NGAI123456789@#$%^&*()*&^%';
    const fontSize = 16;
    const columns = canvas.width / fontSize; 
    const drops = Array(Math.floor(columns)).fill(1);

    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = 'rgba(55, 255, 51, 0.2)';
      ctx.font = `${fontSize}px monospace`;

      drops.forEach((y, i) => {
        const text = letters[Math.floor(Math.random() * letters.length)];
        ctx.fillText(text, i * fontSize, y * fontSize);

        if (y * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        drops[i]++;
      });
    };

    const interval = setInterval(draw, 50);

    return () => clearInterval(interval);
  }, []);

  // Scroll to the bottom of the chat
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Scroll to the bottom whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input.trim();

    // Add user's message to the chat
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      // Send the user's message to the backend API
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userMessage }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Add the assistant's response to the chat letter by letter
      let index = -1;
      const assistantMessage = data.message;
      const interval = setInterval(() => {
        setMessages((prev) => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage && lastMessage.role === 'assistant') {
            if (assistantMessage[index] == undefined) {
              clearInterval(interval);
              return [...prev];
            }
            return [...prev.slice(0, -1), { ...lastMessage, content: lastMessage.content + assistantMessage[index] }];
          } else {
            return [...prev, { role: 'assistant', content: '' + assistantMessage[index] }];
          }
        });
        index++;
        if (index === assistantMessage.length) {
          clearInterval(interval);
        }
      }, 50); 

    } catch (error) {
      console.error('Error:', error);
      setMessages((prev) => [...prev, { role: 'system', content: error.error }]);

    } finally {
      setIsLoading(false);
      // Set a random response time between 0.02ms and 0.05ms
      const randomResponseTime = (Math.random() * (0.05 - 0.02) + 0.02).toFixed(2) + 'ms';
      setResponseTime(randomResponseTime);
    }
  };

  return (
    <>
      <Head>
        <title>NiggAI - AI Assistant Interface</title>
        <meta name="description" content="NiggAI Chat Interface" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-black text-[#33ff33] font-mono p-5 relative">
        <canvas
          id="matrixCanvas"
          className="absolute top-0 left-0 w-full h-full"
          style={{ zIndex: 0 }}
        ></canvas>

        <div className="relative z-10 max-w-3xl mx-auto">
          <pre className="text-center text-xs animate-pulse whitespace-pre">
{` ▐ ▄  ▪   ▄▄ •  ▄▄ •   ▄▄▄·  ▪  
•█▌▐█ ██ ▐█ ▀ ▪▐█ ▀ ▪ ▐█ ▀█  ██ 
▐█▐▐▌▐█·▄█ ▀█▄▄█ ▀█▄ ▄█▀▀█  ▐█·
██▐█▌▐█▌▐█▄▪▐█▐█▄▪▐█ ▐█ ▪▐▌ ▐█▌
▀▀ █▪▀▀▀·▀▀▀▀ ·▀▀▀▀   ▀  ▀  ▀▀▀
==============================================
Have you ever talked to a black person before?
==============================================
`}
          </pre>

          {/* Links Section */}
          <div className="text-center my-5 p-4 border border-[#33ff33]">
            <Link href="https://x.com" target="_blank" className="inline-block mx-4 p-2 border border-[#33ff33] hover:bg-[#33ff33] hover:text-black transition-all">
              [X.COM]
              <pre>{`┌─────┐
│ ><  │
└─────┘`}</pre>
            </Link>
            <Link href="https://telegram.org" target="_blank" className="inline-block mx-4 p-2 border border-[#33ff33] hover:bg-[#33ff33] hover:text-black transition-all">
              [TELEGRAM]
              <pre>{`┌─────┐
│ ✈   │
└─────┘`}</pre>
            </Link>
          </div>

          {/* Chat Section */}
          <div className="border border-[#33ff33] p-4 h-[400px] mb-5 overflow-y-auto">
            <div className="mb-4">
            NiggAI v1.0.0 created to better understand the black community and strengthen the bond between the black and white people #BLM
              ===================================================================================
            </div>

            {/* Display chat messages */}
            {messages.map((msg, i) => (
              <div key={i} className="mb-2">
                &gt; {msg.role === 'user' ? 'You: ' : msg.role === 'assistant' ? 'NiggAI: ' : 'System: '}
                {msg.content}
              </div>
            ))}

            {/* Show loading animation */}
            {isLoading && (
              <div className="animate-pulse">&gt; Processing input...</div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="border border-[#33ff33] p-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full bg-black text-[#33ff33] outline-none"
              placeholder="> Enter your message..."
              disabled={isLoading}
            />
          </form>

          {/* Footer Section */}
          <div className="text-center mt-5">
            [Status: ONLINE] | [Memory: 98% Available] | [Response Time: {responseTime}]
          </div>
        </div>
      </div>
    </>
  );
}
